export interface Council {
    councilName : string;
    councilAddress : string;
    councilCity : string;
    councilState : string;
    councilLeaderEmail : string;
    councilCreatedBy : string;
    councilCreatedAt : string;
}