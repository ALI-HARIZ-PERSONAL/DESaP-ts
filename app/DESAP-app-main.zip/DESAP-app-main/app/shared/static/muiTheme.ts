"use client";

import { createTheme } from "@mui/material/styles";

const materialUITheme = createTheme();

export default materialUITheme;
